#include "optional.h"

/* The one Nothing. */
nothing_t Nothing;
